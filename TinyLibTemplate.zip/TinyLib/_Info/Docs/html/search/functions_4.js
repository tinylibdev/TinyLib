var searchData=
[
  ['file_0',['File',['../classtl_1_1_file.html#aefe659f313e7467f1a4649f37b8a26b5',1,'tl::File::File()'],['../classtl_1_1_file.html#a1e6a2206626b3050f4cc15cca8a29825',1,'tl::File::File(const char *path)']]],
  ['free_1',['free',['../namespacetl.html#a27f87676958c34ab5d023c25d954a58a',1,'tl']]]
];
