var searchData=
[
  ['_5ffltused_0',['_fltused',['../_memory_8cpp.html#a4cf04c7a2389a90415c8032ce5e58e50',1,'_fltused:&#160;Memory.cpp'],['../_memory_8h.html#a4cf04c7a2389a90415c8032ce5e58e50',1,'_fltused:&#160;Memory.h']]],
  ['_5fwin32_5fwinnt_1',['_WIN32_WINNT',['../_win_a_p_i_8h.html#ac50762666aa00bd3a4308158510f1748',1,'WinAPI.h']]]
];
