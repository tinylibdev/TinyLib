var searchData=
[
  ['text_0',['Text',['../classtl_1_1_text.html',1,'tl']]],
  ['time_1',['Time',['../classtl_1_1_time.html',1,'tl']]]
];
