var searchData=
[
  ['getcapacity_0',['getCapacity',['../classtl_1_1_vector.html#abdd4105bc63e8757f0bf76162b3f61e2',1,'tl::Vector']]],
  ['getcolor_1',['getColor',['../classtl_1_1_drawable.html#acf6f9bbe46b4badaa8d4949a93c818ba',1,'tl::Drawable']]],
  ['getposition_2',['getPosition',['../classtl_1_1_drawable.html#ae72500b4134b8187966650dcfc07b27f',1,'tl::Drawable::getPosition()'],['../classtl_1_1_window.html#a622a8eaf9557f44baa439e47133e0b8c',1,'tl::Window::getPosition()'],['../classtl_1_1_mouse.html#a0414734ff08c547927abbcfd7f0a55e5',1,'tl::Mouse::getPosition()']]],
  ['getsize_3',['getSize',['../classtl_1_1_vector.html#a7a59cdb82916ebab5ae46f1b8f1efec6',1,'tl::Vector::getSize()'],['../classtl_1_1_drawable.html#a09bca9a11e2fc75ad5298f5bf0c6399f',1,'tl::Drawable::getSize()'],['../classtl_1_1_window.html#a2bcf4a5045beca6be155f7fe5063e12e',1,'tl::Window::getSize()']]],
  ['getstring_4',['getString',['../classtl_1_1_text.html#a342716a8b9b9f950fed58d3e73eb1035',1,'tl::Text']]],
  ['gettime_5',['getTime',['../classtl_1_1_time.html#a69a320e7414645c62a9f63d52d907a02',1,'tl::Time']]]
];
