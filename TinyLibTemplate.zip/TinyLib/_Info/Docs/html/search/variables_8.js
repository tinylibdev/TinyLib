var searchData=
[
  ['sizex_0',['sizeX',['../classtl_1_1_drawable.html#a06d58589b24ff1ba0d8a0c776a3a0eeb',1,'tl::Drawable']]],
  ['sizey_1',['sizeY',['../classtl_1_1_drawable.html#ad9f165dbfcfff7a16d8e9e3862838675',1,'tl::Drawable']]]
];
