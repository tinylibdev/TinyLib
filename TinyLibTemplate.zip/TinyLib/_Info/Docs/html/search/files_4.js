var searchData=
[
  ['graphicscategory_2eh_0',['GraphicsCategory.h',['../_graphics_category_8h.html',1,'']]]
];
