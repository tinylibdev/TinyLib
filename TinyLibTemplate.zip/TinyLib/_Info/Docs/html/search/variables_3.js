var searchData=
[
  ['g_0',['g',['../structtl_1_1_color.html#acabb8eda91ed6d102b19a6b74f43e206',1,'tl::Color::g'],['../classtl_1_1_drawable.html#a4d46800e890cd5d5a62b500fe9c982f1',1,'tl::Drawable::g']]]
];
