var searchData=
[
  ['basecategory_2eh_0',['BaseCategory.h',['../_base_category_8h.html',1,'']]]
];
