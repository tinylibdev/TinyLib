var searchData=
[
  ['posx_0',['posX',['../classtl_1_1_drawable.html#a005875cab6106fa1c8983884ee3a7072',1,'tl::Drawable']]],
  ['posy_1',['posY',['../classtl_1_1_drawable.html#adc938c28638d39be3c53207ee625611d',1,'tl::Drawable']]]
];
