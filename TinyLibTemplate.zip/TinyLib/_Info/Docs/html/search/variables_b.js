var searchData=
[
  ['x_0',['x',['../structtl_1_1_vec2i.html#a41e041952704574074609118c0427518',1,'tl::Vec2i::x'],['../structtl_1_1_vec3i.html#a02a1f2ca39aef67993540a544bab8856',1,'tl::Vec3i::x']]]
];
