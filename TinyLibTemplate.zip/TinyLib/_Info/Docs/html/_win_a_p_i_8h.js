var _win_a_p_i_8h =
[
    [ "_WIN32_WINNT", "_win_a_p_i_8h.html#ac50762666aa00bd3a4308158510f1748", null ]
];