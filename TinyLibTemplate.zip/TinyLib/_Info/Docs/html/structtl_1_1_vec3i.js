var structtl_1_1_vec3i =
[
    [ "Vec3i", "structtl_1_1_vec3i.html#af6461379b5a15b3c3dd098deddd9dbb6", null ],
    [ "x", "structtl_1_1_vec3i.html#a02a1f2ca39aef67993540a544bab8856", null ],
    [ "y", "structtl_1_1_vec3i.html#a7a92050183a837edc7c4de9290436795", null ],
    [ "z", "structtl_1_1_vec3i.html#a8c9b9a6bf5d2e2995958b6c5064f62fc", null ]
];