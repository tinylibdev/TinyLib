var _text_8h =
[
    [ "tl::Text", "classtl_1_1_text.html", "classtl_1_1_text" ]
];