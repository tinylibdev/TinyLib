var structtl_1_1_color =
[
    [ "Color", "structtl_1_1_color.html#aa8219d93b98b8c371ba5dcaa63cc5c91", null ],
    [ "a", "structtl_1_1_color.html#ab1a26f98553d0893174c15971de67a34", null ],
    [ "b", "structtl_1_1_color.html#a3bf83204b4a0ed202d04f0c09fac4e95", null ],
    [ "g", "structtl_1_1_color.html#acabb8eda91ed6d102b19a6b74f43e206", null ],
    [ "r", "structtl_1_1_color.html#a353edd65a9c14c9e9fc12b3a2bd8a8c8", null ]
];