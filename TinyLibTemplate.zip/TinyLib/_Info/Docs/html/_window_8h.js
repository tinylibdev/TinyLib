var _window_8h =
[
    [ "tl::Window", "classtl_1_1_window.html", "classtl_1_1_window" ],
    [ "Event", "_window_8h.html#a7e2989f2c8039c3f533555e5255c654d", [
      [ "Closed", "_window_8h.html#a7e2989f2c8039c3f533555e5255c654da5be4e5d266410d4098330ef298d0a590", null ],
      [ "Moved", "_window_8h.html#a7e2989f2c8039c3f533555e5255c654daed0acb15944cd2abce85da77065f7ba0", null ],
      [ "Resized", "_window_8h.html#a7e2989f2c8039c3f533555e5255c654da60573197598e5aa232348f6efb3f7066", null ]
    ] ],
    [ "Style", "_window_8h.html#a36ce4a17d54a1939d694bf6d68cf0308", [
      [ "Border", "_window_8h.html#a36ce4a17d54a1939d694bf6d68cf0308ac470c51a77675dff2188539f3dd814d1", null ],
      [ "Title", "_window_8h.html#a36ce4a17d54a1939d694bf6d68cf0308a36aa6aca3d046b2750e31acd37ca341b", null ],
      [ "Background", "_window_8h.html#a36ce4a17d54a1939d694bf6d68cf0308a7c7515c26f63d97a9f392debb0affa9c", null ],
      [ "Fullscreen", "_window_8h.html#a36ce4a17d54a1939d694bf6d68cf0308ad03932612fa61f868ab83759cf89f8bd", null ],
      [ "Minimize", "_window_8h.html#a36ce4a17d54a1939d694bf6d68cf0308afe4367e3cf35673f041e46ddcf641c58", null ],
      [ "Maximize", "_window_8h.html#a36ce4a17d54a1939d694bf6d68cf0308aabdd212e2b4673d041c8d9bdf192a6da", null ],
      [ "Resize", "_window_8h.html#a36ce4a17d54a1939d694bf6d68cf0308a96d5232c5dacb561d06868bddd8662cc", null ],
      [ "Default", "_window_8h.html#a36ce4a17d54a1939d694bf6d68cf0308a37707492d112fc66861dba3bda903db8", null ]
    ] ]
];