var annotated_dup =
[
    [ "tl", "namespacetl.html", [
      [ "Color", "structtl_1_1_color.html", "structtl_1_1_color" ],
      [ "Console", "classtl_1_1_console.html", "classtl_1_1_console" ],
      [ "Drawable", "classtl_1_1_drawable.html", "classtl_1_1_drawable" ],
      [ "File", "classtl_1_1_file.html", "classtl_1_1_file" ],
      [ "Key", "classtl_1_1_key.html", null ],
      [ "Mouse", "classtl_1_1_mouse.html", null ],
      [ "Rectangle", "classtl_1_1_rectangle.html", "classtl_1_1_rectangle" ],
      [ "Text", "classtl_1_1_text.html", "classtl_1_1_text" ],
      [ "Time", "classtl_1_1_time.html", "classtl_1_1_time" ],
      [ "Vec2i", "structtl_1_1_vec2i.html", "structtl_1_1_vec2i" ],
      [ "Vec3i", "structtl_1_1_vec3i.html", "structtl_1_1_vec3i" ],
      [ "Vec4i", "structtl_1_1_vec4i.html", "structtl_1_1_vec4i" ],
      [ "Vector", "classtl_1_1_vector.html", "classtl_1_1_vector" ],
      [ "Window", "classtl_1_1_window.html", "classtl_1_1_window" ]
    ] ]
];