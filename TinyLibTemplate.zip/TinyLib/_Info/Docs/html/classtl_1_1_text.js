var classtl_1_1_text =
[
    [ "Text", "classtl_1_1_text.html#aead89526f1134efdbb683662d503ecce", null ],
    [ "~Text", "classtl_1_1_text.html#a12cfa88d0cea89d2e553d8cbde046f41", null ],
    [ "getString", "classtl_1_1_text.html#a342716a8b9b9f950fed58d3e73eb1035", null ],
    [ "setFontSize", "classtl_1_1_text.html#af448df96815b0aa650eec8a2cf5bcc0d", null ],
    [ "setString", "classtl_1_1_text.html#a32191037254d9cf575cb9677be4536ae", null ]
];