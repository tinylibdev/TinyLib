var dir_28b92148d644b50efd4463f16a6f2645 =
[
    [ "Base", "dir_5591fab9144961baab07d2b3df2fbfba.html", "dir_5591fab9144961baab07d2b3df2fbfba" ],
    [ "Console", "dir_aff9cf94a93c36559545baa5bef5ce6f.html", "dir_aff9cf94a93c36559545baa5bef5ce6f" ],
    [ "Graphics", "dir_a5c62c1f23eb087e4b88afb25fe12615.html", "dir_a5c62c1f23eb087e4b88afb25fe12615" ],
    [ "System", "dir_216e93b49eb56a33e05d07a6099ccd0f.html", "dir_216e93b49eb56a33e05d07a6099ccd0f" ],
    [ "TinyLib.h", "_tiny_lib_8h.html", null ]
];