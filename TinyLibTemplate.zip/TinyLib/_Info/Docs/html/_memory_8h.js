var _memory_8h =
[
    [ "FLOAT_SUPPORT_H", "_memory_8h.html#ad53e3688505c50e73a25b9de46f9f083", null ],
    [ "free", "_memory_8h.html#a27f87676958c34ab5d023c25d954a58a", null ],
    [ "malloc", "_memory_8h.html#a2ac98dd95bdf0b59af459a290354c589", null ],
    [ "memset", "_memory_8h.html#a60ed7fe786cba3286c6ba182199163fa", null ],
    [ "operator delete", "_memory_8h.html#afa145befcf5e7b83424408ca503c8637", null ],
    [ "operator delete", "_memory_8h.html#a91e676caef3a7611d29e053ed1789a1a", null ],
    [ "operator delete[]", "_memory_8h.html#a22aea74a1155aa798d6032da46da2391", null ],
    [ "operator new", "_memory_8h.html#a1a7f24760c8c7ad3bfcd54856d906fc2", null ],
    [ "operator new[]", "_memory_8h.html#aa75472ab4b765cf6f6b5b0ebcd4a28c8", null ],
    [ "_fltused", "_memory_8h.html#a4cf04c7a2389a90415c8032ce5e58e50", null ]
];