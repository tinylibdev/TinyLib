var hierarchy =
[
    [ "tl::Color", "structtl_1_1_color.html", null ],
    [ "tl::Console", "classtl_1_1_console.html", null ],
    [ "tl::Drawable", "classtl_1_1_drawable.html", [
      [ "tl::Rectangle", "classtl_1_1_rectangle.html", null ],
      [ "tl::Text", "classtl_1_1_text.html", null ]
    ] ],
    [ "tl::File", "classtl_1_1_file.html", null ],
    [ "tl::Key", "classtl_1_1_key.html", null ],
    [ "tl::Mouse", "classtl_1_1_mouse.html", null ],
    [ "tl::Time", "classtl_1_1_time.html", null ],
    [ "tl::Vec2i", "structtl_1_1_vec2i.html", null ],
    [ "tl::Vec3i", "structtl_1_1_vec3i.html", null ],
    [ "tl::Vec4i", "structtl_1_1_vec4i.html", null ],
    [ "tl::Vector< T >", "classtl_1_1_vector.html", null ],
    [ "tl::Window", "classtl_1_1_window.html", null ]
];